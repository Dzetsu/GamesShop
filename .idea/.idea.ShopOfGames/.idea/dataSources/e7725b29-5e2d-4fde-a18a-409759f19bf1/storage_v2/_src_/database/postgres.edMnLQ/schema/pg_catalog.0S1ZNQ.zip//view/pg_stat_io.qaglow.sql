create view pg_stat_io
            (backend_type, object, context, reads, read_bytes, read_time, writes, write_bytes, write_time, writebacks,
             writeback_time, extends, extend_bytes, extend_time, hits, evictions, reuses, fsyncs, fsync_time,
             stats_reset)
as
SELECT backend_type,
       object,
       context,
       reads,
       read_bytes,
       read_time,
       writes,
       write_bytes,
       write_time,
       writebacks,
       writeback_time,
       extends,
       extend_bytes,
       extend_time,
       hits,
       evictions,
       reuses,
       fsyncs,
       fsync_time,
       stats_reset
FROM pg_stat_get_io() b(backend_type, object, context, reads, read_bytes, read_time, writes, write_bytes, write_time,
                        writebacks, writeback_time, extends, extend_bytes, extend_time, hits, evictions, reuses, fsyncs,
                        fsync_time, stats_reset);

alter table pg_stat_io
    owner to postgres;

grant select on pg_stat_io to public;

